char *MakeCString(char *str, unsigned int len);
float sglsin(float num);
float sglcos(float num);