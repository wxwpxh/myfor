void Win32FullScreen(int width, int height, int bpps, int doublebuffer);
void Win32CreateWindow(int cx, int cy, int width, int height, int doublebuffer);
void Win32MainLoop(void);
void Win32Timer(int time);
void Win32SetTitle(char *str);
void Win32ShowCursor(int show);



