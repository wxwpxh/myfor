#ifndef DIRECTX
  #define DIRECTX
#endif

#ifndef WIN32
  #define WIN32
#endif